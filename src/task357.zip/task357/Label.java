package task357;

enum Label {
    SPAM, NEGATIVE_TEXT, TOO_LONG, OK
}
