package task357;

interface TextAnalyzer {
    Label processText(String text);

}


